# Ponify.ng e-commerce starter

Free GitHub Pages-ready customer storefront + starter admin UI.

## Launch
1. Create a GitHub account.
2. Create a PUBLIC repository called `ponify-store` (or `<yourusername>.github.io` for a root site).
3. Upload the contents of this folder, keeping `index.html` at the repository root.
4. Settings → Pages → Deploy from branch → `main` → `/root` → Save.
5. GitHub will provide your free `github.io` URL.

## Admin
Open `/admin/`. The current starter stores product edits in the browser's localStorage. It is NOT a secure multi-user admin/database yet.

## Next upgrade
Connect Supabase for secure authentication, products, inventory, orders and image storage. GitHub Pages remains the free frontend host.
